function res = CaCO3bc(CaCO3a,CaCO3b)
global F_CaCO3 v_burial poros rho Bioturb

NPP1 = F_CaCO3 * 1E-4; %gram/cm2/year
v_burial1 = v_burial(1,1);  %cm/year
poros1 = poros(1,1); 
A1 = rho * (1-poros1);
Bioturb1 = Bioturb(1,1);

BC_1 = - Bioturb1 * A1 * CaCO3a(2) + A1 * v_burial1 * CaCO3a(1) - NPP1;

res = [ BC_1 
        CaCO3b(2)];

end


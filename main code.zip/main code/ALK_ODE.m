
function dydx = ALK_ODE(x,ALK)
global DHCO3 Alpha_Bioirrig HCO3init R_SRR RC
global v_burial_Fluid z_sed R1_carb poros R_respi R_HS_Ox R_FeS 
global kFeS C_HS C_Fe

v_burial_f = interp1(z_sed,v_burial_Fluid,x);
Alpha_Bioirrig_1 = interp1(z_sed,Alpha_Bioirrig,x);
fi = interp1(z_sed,poros,x);
R1_carb1 = interp1(z_sed,R1_carb,x);
R_SRR1 = interp1(z_sed,R_SRR,x);
R_HS_Ox1 = interp1(z_sed,R_HS_Ox,x);
RC1 = interp1(z_sed,RC,x);
R_respi1 = interp1(z_sed,R_respi,x);
R_ALK = RC1.*1E9 - 0.5.*R_SRR1;
R_FeS_1 = interp1(z_sed,R_FeS,x);
C_HS_1 = interp1(z_sed,C_HS,x);
C_Fe_1 = interp1(z_sed,C_Fe,x);



NR = + v_burial_f.* ALK(2) - 2.*(kFeS.*C_Fe_1.*C_HS_1) + 2.*R1_carb1 - (Alpha_Bioirrig_1.*(HCO3init-ALK(1))); % umol/l/year

% R_ALK + 2.*R1_carb1 + 2.*R_HS_Ox1 - (Alpha_Bioirrig_1.*(HCO3init-ALK(1))); % umol/l/year
dydx = [ ALK(2) /fi/DHCO3
           NR];

end


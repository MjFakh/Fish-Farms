function res = CaCO3_bc1(CaCO3a,CaCO3b)
global CaCO3_init
  res = [ CaCO3a(1)-CaCO3_init
          CaCO3b(2) ];
 
end
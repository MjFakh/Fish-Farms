function dydx = CaCO3ODE(x,CaCO3)
global v_burial z_sed Bioturb sigma_carb k_calcite
global n_power_CaCO31 n_power_CaCO32 n_power_CaCO33
global k_calcite_dis1 k_calcite_dis2 rho poros

v_burial_1 = interp1(z_sed,v_burial,x);
sigma_carb1 = interp1(z_sed,sigma_carb,x);
Db = interp1(z_sed,Bioturb,x);
poros_1 = interp1(z_sed,poros,x);
unit_conversion = 1./(1E3.*1E6.*1E-2.*rho.*(1-poros_1));
fi = interp1(z_sed,poros,x);
sigh = 1 - fi;


NR = + v_burial_1.* CaCO3(2) - ((sigma_carb1 > 0 & sigma_carb1 == 0).*abs(sigma_carb1).^n_power_CaCO31.* k_calcite.*unit_conversion)...
     + (-0.2 < sigma_carb1 & sigma_carb1 < 0).*abs(sigma_carb1).^n_power_CaCO32.* k_calcite_dis1.*CaCO3(1)...
     + (-0.2 > sigma_carb1).*abs(sigma_carb1).^n_power_CaCO33.* k_calcite_dis2.*CaCO3(1);  %g/gDw/year

dydx = [ CaCO3(2) /sigh/Db
         NR];

end

function res = ALK_bc(ALKa,ALKb)
global HCO3init
  res = [ ALKa(1)- HCO3init 
          ALKb(2) ];
 
end
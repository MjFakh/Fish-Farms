
function dydx = DIC_ODE(x,DIC)
global DHCO3 RC Alpha_Bioirrig R1_carb v_burial_Fluid z_sed poros DICinit

v_burial_f = interp1(z_sed,v_burial_Fluid,x);
Alpha_Bioirrig_1 = interp1(z_sed,Alpha_Bioirrig,x);
fi = interp1(z_sed,poros,x);
R1_carb1 = interp1(z_sed,R1_carb,x);

RC1 = interp1(z_sed,RC,x);

NR = + v_burial_f.* DIC(2) - RC1.*1E9 + R1_carb1 - (Alpha_Bioirrig_1.*(DICinit-DIC(1))); % umol/l/year
dydx = [ DIC(2) /fi/DHCO3
           NR];

end